urdf2rai.py ur10.urdf > z.1.g
kinEdit -file z.1.g -cleanOnly
mv z.g ur10_clean.g
